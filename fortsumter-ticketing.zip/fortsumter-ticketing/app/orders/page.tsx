export default function Orders() {
  const orders = [
    { id: 1, item: "Ticket A", date: "2025-09-01" },
    { id: 2, item: "Ticket B", date: "2025-09-03" },
    { id: 3, item: "Ticket C", date: "2025-09-05" },
  ];

  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-purple-50 to-purple-100">
      <h1 className="text-4xl font-bold mb-8 text-purple-700">Orders</h1>
      <ul className="w-full max-w-md space-y-4">
        {orders.map((order) => (
          <li
            key={order.id}
            className="bg-white rounded-lg shadow p-4 flex justify-between items-center text-lg font-medium"
          >
            <span>
              Order #{order.id}: {order.item}
            </span>
            <span className="text-gray-500 text-sm">{order.date}</span>
          </li>
        ))}
      </ul>
    </main>
  );
}
