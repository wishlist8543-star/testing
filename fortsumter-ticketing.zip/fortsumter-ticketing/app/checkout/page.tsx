import Link from "next/link";

export default function Checkout() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      <h1 className="text-4xl font-bold mb-8 text-green-700">Checkout Page</h1>
      <form className="bg-white rounded-lg shadow p-6 mb-8 w-full max-w-md flex flex-col gap-4">
        <label className="font-medium text-gray-700">
          Full Name
          <input
            type="text"
            className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400"
            placeholder="Full Name"
          />
        </label>
        <label className="font-medium text-gray-700">
          Email Address
          <input
            type="email"
            className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400"
            placeholder="you@email.com"
          />
        </label>
        <label className="font-medium text-gray-700">
          Shipping Address
          <input
            type="text"
            className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400"
            placeholder="123 Main St, City"
          />
        </label>
        <label className="font-medium text-gray-700">
          Card Number
          <input
            type="text"
            maxLength={16}
            className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400"
            placeholder="1234 5678 9012 3456"
          />
        </label>
        <div className="flex gap-4">
          <label className="font-medium text-gray-700 w-1/2">
            Expiry
            <input
              type="text"
              maxLength={5}
              className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400"
              placeholder="MM/YY"
            />
          </label>
          <label className="font-medium text-gray-700 w-1/2">
            CVC
            <input
              type="text"
              maxLength={4}
              className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400"
              placeholder="CVC"
            />
          </label>
        </div>
        <label className="font-medium text-gray-700">
          Ticket Type
          <select className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400">
            <option>General Admission</option>
            <option>VIP</option>
            <option>Student</option>
          </select>
        </label>
        <Link
          href={"/orders"}
          className="px-6 py-3 rounded-lg bg-green-600 text-white font-semibold shadow hover:bg-green-700 transition-all duration-200"
        >
          Pay & Checkout
        </Link>
      </form>
    </main>
  );
}
